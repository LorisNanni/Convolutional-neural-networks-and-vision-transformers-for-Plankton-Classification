import copy
import math
import argparse
import os
import os.path as osp

import torch
import torch.nn as nn
import timm

from PIL import Image
from tqdm import tqdm
import tensorboardX
import numpy as np
from sklearn.metrics import f1_score

from dataloader import PatternData




if __name__ == '__main__':

    parser = argparse.ArgumentParser(description='')
    parser.add_argument('--root', type=str, default='/mnt')
    parser.add_argument('--dataset', type=str)
    parser.add_argument('--num_classes', type=int, default=3)
    parser.add_argument('--batch_size', type=int, default=32)
    parser.add_argument('--val_batch_size', type=int, default=1)
    parser.add_argument('--num_epocs', type=int, default=50)
    parser.add_argument('--model_name', type=str, default='deit')
    # parser.add_argument('--fold', type=int, default=0)
    parser.add_argument('--startf', type=int, default=0)
    parser.add_argument('--endf', type=int, default=1)
    parser.add_argument('--starti', type=int, default=0)
    parser.add_argument('--endi', type=int, default=1)
    parser.add_argument('--adamwd', type=bool, default=False)
    parser.add_argument("--split", type=int, default=4)
    parser.add_argument('--num_workers', type=int, default=4)
    parser.add_argument('--no_test_metrics', action='store_true')

    args = parser.parse_args()

    num_classes = args.num_classes
    dataset = args.dataset
    batch_size = args.batch_size
    val_batch_size = args.val_batch_size
    num_epocs = args.num_epocs
    lr_rates = [0.0001, 0.00001, 0.000001]
    model_name = args.model_name
    startf = args.startf
    endf = args.endf
    starti = args.starti
    endi = args.endi
    # optim = args.optim
    root = args.root
    split = args.split
    num_workers = args.num_workers
    test_metrics = not args.no_test_metrics

    model_name_save = model_name
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")



    for fold in range(startf, endf):
        print("FOLD: ", fold)
        dataset_name = dataset.split("/")[-1].split(".")[0]

        for n_m in range(starti, endi):
            n = str(n_m)
            print("Number: ", n_m)

            writer = tensorboardX.SummaryWriter(
                log_dir=root + '/runs/' + dataset_name + '_model_' + model_name_save + '_' + str(fold) + '_' + n)
            input_size = 224

            if model_name == "vit":
                model = timm.create_model('vit_base_patch16_224', pretrained=True, num_classes=num_classes)
            elif model_name == "deit":
                model = timm.create_model('deit_base_distilled_patch16_224', pretrained=True,
                                          num_classes=num_classes)
            elif model_name == "swin":
                model = timm.create_model('swin_base_patch4_window7_224', pretrained=True, num_classes=num_classes)
            elif model_name == "coatnet":
                model = timm.create_model('coatnet_rmlp_2_rw_224', pretrained=True, num_classes=num_classes)
            elif model_name == "beit":
                model = timm.create_model('beit_base_patch16_224', pretrained=True, num_classes=num_classes)
            elif model_name == "beit2":
                model = timm.create_model('beitv2_base_patch16_224', pretrained=True, num_classes=num_classes)
            elif model_name == "beitl":
                model = timm.create_model('beit_large_patch16_224.in22k_ft_in22k', pretrained=True,
                                          num_classes=num_classes)
            elif model_name == "beitl384":
                model = timm.create_model('beit_large_patch16_384.in22k_ft_in22k_in1k', pretrained=True,
                                          num_classes=num_classes)
                input_size = 384
            elif model_name == "beitl2":
                model = timm.create_model('beitv2_large_patch16_224.in1k_ft_in22k', pretrained=True,
                                          num_classes=num_classes)
            elif model_name == "vitl":
                model = timm.create_model('vit_large_patch16_224', pretrained=True, num_classes=num_classes)
            elif model_name == "vitl384":
                model = timm.create_model('vit_large_patch32_384.orig_in21k_ft_in1k', pretrained=True,
                                          num_classes=num_classes)
                input_size = 384
            elif model_name == "swinl":
                model = timm.create_model('swin_large_patch4_window7_224.ms_in22k', pretrained=True,
                                          num_classes=num_classes)
            elif model_name == "swinl384":
                model = timm.create_model('swin_large_patch4_window12_384.ms_in22k', pretrained=True,
                                          num_classes=num_classes)
                input_size = 384

            if torch.cuda.device_count() > 1:
                print("Let's use", torch.cuda.device_count(), "GPUs!")
                model = nn.DataParallel(model)

            model.to(device)


            testset = PatternData(dataset, mode="test", fold=fold, input_size=input_size, split=split)
            testloader = torch.utils.data.DataLoader(testset, batch_size=batch_size, shuffle=False, num_workers=num_workers)
            model.eval()



            with torch.no_grad():
                for k, (x, y) in enumerate((testloader)):
                    x = x.cuda()
                    y = y.cuda()

                    # compute the time needed for the forward pass
                    torch.cuda.synchronize()
                    start = torch.cuda.Event(enable_timing=True)
                    end = torch.cuda.Event(enable_timing=True)

                    start.record()
                    for i in range(100):
                        outputs = model(x)
                    end.record()
                    torch.cuda.synchronize()

                    # compute the time needed for the forward pass
                    time_forward = start.elapsed_time(end)
                    print("Time forward pass: ", time_forward/100, "ms")
                    break
