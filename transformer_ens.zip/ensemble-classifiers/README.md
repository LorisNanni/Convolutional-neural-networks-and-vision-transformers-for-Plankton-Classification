# Information
This is the code for training each transformer model of the ensemble.

# Installation
The code is written in Python 3.8 and PyTorch 1.13. We used 4 gpus for the training.

1) Install pytorch and torchvision from the official website. 
2) Install the following libraries using pip:

```bash
pip install -r requirements.txt
```

# Data for training
Data are in mat format. 


# Training and testing

1) Crete a folder 'out_models' that will store the trained models
2) Create a folder 'out_txt' that will store the results of the test

To train the model, run the following command:

```bash
python3 train_optimizers.py --endi 7 --starti 0 --endf NUMBER_OF_FOLD --startf 0 --dataset PATH_TO_DATASET --num_classes NUM_CLASSES --model_name MODEL_NAME --adamwd True --optim adamw --batch_size BATCH_SIZE --split NUMBER_OF_PARTS
``` 

After training the model will be tested producing the logits for each sample in the test. If you want to replicate the experiments you should apply softmax. 

### Parameters
PATH_TO_DATASET path to the dataset; 

NUMBER_OF_FOLD number of folds;

NUM_CLASSES number of classes;

MODEL_NAME choose between "vit", "deit", "swin", "coatnet", "beit", "beit2", "beitl", "beitl384", "beitl2", "vitl", "vitl384", "swinl", "swinl384";

BATCH_SIZE for batch size;

NUMBER_OF_PARTS is the dimension of the validation split as 1/NUMBER_OF_PARTS;

if the number of test classes is different compared to the training classes, you can add the following parameter to avoid computing the test metrics:
--no_test_metrics


