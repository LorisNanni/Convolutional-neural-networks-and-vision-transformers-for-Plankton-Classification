import copy
import math
import argparse
import os
import os.path as osp

import torch
import torch.nn as nn
import timm

from PIL import Image
from tqdm import tqdm
import tensorboardX
import numpy as np
from sklearn.metrics import f1_score

from dataloader import PatternData

from optimizers.DGrad import DGrad
from optimizers.DiffGrad import DiffGrad
from optimizers.Cos import Cos
from optimizers.Exp import Exp
from optimizers.Hyp import Hyp
from optimizers.MinD import MinD
from optimizers.AngularInjection import AngularInjection

def train(model, optim, dataloader, criterion, num_classes):
    running_loss = 0.0
    number_of_elements = len(dataloader)
    correct_prediction = 0
    predictions = 0

    #conf_mat = np.zeros((20, 20))
    all_gts = []
    all_preds = []

    for k, (x, y) in enumerate((dataloader)):

        x = x.cuda()
        y = y.cuda()

        optim.zero_grad()

        outputs = model(x)

        loss = criterion(outputs, y)
        
        loss.backward()
        optim.step()

        preds = torch.argmax(outputs, dim=1)

        correct_prediction += torch.count_nonzero(preds == y)
        predictions += len(preds)
        running_loss += loss.item()/number_of_elements

        all_gts += list(y.cpu().numpy())
        all_preds += list(preds.detach().cpu().numpy())

    acc = float(correct_prediction)/predictions

    return running_loss, acc, f1_score(np.array(all_gts), np.array(all_preds), labels=np.array(list(range(num_classes))), average='macro')


def val(model, dataloader, criterion, num_classes):
    running_loss = 0.0
    number_of_elements = len(dataloader)
    correct_prediction = 0
    predictions = 0

    all_gts = []
    all_preds = []

    for k, (x, y) in enumerate((dataloader)):
        x = x.cuda()
        y = y.cuda()

        outputs = model(x)
        loss = criterion(outputs, y)
        running_loss += loss.item() / number_of_elements

        # compute metrics
        preds = torch.argmax(outputs, dim=1)
        correct_prediction += torch.count_nonzero(preds == y)
        predictions += len(preds)
        running_loss += loss.item() / number_of_elements

        all_gts += list(y.cpu().numpy())
        all_preds += list(preds.detach().cpu().numpy())

    acc = float(correct_prediction) / predictions

    return running_loss, acc, f1_score(np.array(all_gts), np.array(all_preds), labels=np.array(list(range(num_classes))), average='macro')

def test(model, dataloader, criterion, mode="", file_name="", nc=1, compute_metrics=True):
    running_loss = 0.0
    number_of_elements = len(dataloader)
    correct_prediction = 0
    predictions = 0

    all_gts = []
    all_preds = []

    if file_name != "":
        file = open(file_name+".txt", "w")
        #files = open(file_name+"_softmax.txt", "w")

    for k, (x, y) in enumerate((dataloader)):
        x = x.cuda()
        y = y.cuda()

        outputs = model(x)

        if file_name != "":
            file.write("gt:"+str(y.cpu().numpy()[0])+";")
            for e in outputs.cpu().numpy()[0]:
                file.write(str(e)+";")
            file.write("\n")

            #files.write("gt:"+str(y.cpu().numpy()[0])+";")
            #for e in nn.functional.softmax(outputs).cpu().numpy()[0]:
            #    files.write(str(e)+";")
            #files.write("\n")
        if compute_metrics:
            loss = criterion(outputs, y)
            running_loss += loss.item() / number_of_elements

            # compute metrics
            preds = torch.argmax(outputs, dim=1)
            correct_prediction += torch.count_nonzero(preds == y)
            predictions += len(preds)
            running_loss += loss.item() / number_of_elements

            all_gts += list(y.cpu().numpy())
            all_preds += list(preds.detach().cpu().numpy())

    if compute_metrics:
        acc = float(correct_prediction) / predictions

    if file_name != "":
        file.close()
        #files.close()
    if compute_metrics:
        return running_loss, acc, f1_score(np.array(all_gts), np.array(all_preds), labels=np.array(list(range(nc))), average='macro')
    else:
        return -1, -1, -1
class LRScheduler:
    """
    Learning rate scheduler. If the validation loss does not decrease for the
    given number of `patience` epochs, then the learning rate will decrease by
    by given `factor`.
    """

    def __init__(
            self, optimizer, patience=4, min_lr=1e-10, factor=0.5
    ):
        """
        new_lr = old_lr * factor
        :param optimizer: the optimizer we are using
        :param patience: how many epochs to wait before updating the lr
        :param min_lr: least lr value to reduce to while updating
        :param factor: factor by which the lr should be updated
        """
        self.optimizer = optimizer
        self.patience = patience
        self.min_lr = min_lr
        self.factor = factor
        self.lr_scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
            self.optimizer,
            mode='min',
            patience=self.patience,
            factor=self.factor,
            min_lr=self.min_lr,
            verbose=True
        )

    def __call__(self, val_loss):
        self.lr_scheduler.step(val_loss)

def adjust_learning_rate(optimizer, epoch, lr, warmup, disable_cos, epochs):
    lr = lr
    if epoch < warmup:
        lr = lr / (warmup - epoch)
    elif not disable_cos:
        lr *= 0.5 * (1. + math.cos(math.pi * (epoch - warmup) / (epochs - warmup)))

    for param_group in optimizer.param_groups:
        param_group['lr'] = lr


if __name__ == '__main__':

    parser = argparse.ArgumentParser(description='')
    parser.add_argument('--root', type=str, default='/mnt')
    parser.add_argument('--dataset', type=str)
    parser.add_argument('--num_classes', type=int, default=3)
    parser.add_argument('--batch_size', type=int, default=32)
    parser.add_argument('--val_batch_size', type=int, default=1)
    parser.add_argument('--num_epocs', type=int, default=50)
    parser.add_argument('--model_name', type=str, default='deit')
    #parser.add_argument('--fold', type=int, default=0)
    parser.add_argument('--startf', type=int, default=0)
    parser.add_argument('--endf', type=int, default=1)
    parser.add_argument('--starti', type=int, default=0)
    parser.add_argument('--endi', type=int, default=1)
    parser.add_argument('--optim', type=str, nargs='+')
    parser.add_argument('--adamwd', type=bool, default=False)
    parser.add_argument("--split", type=int, default=4)
    parser.add_argument('--num_workers', type=int, default=4)
    parser.add_argument('--no_test_metrics', action='store_true')

    args = parser.parse_args()

    num_classes = args.num_classes
    dataset = args.dataset 
    batch_size = args.batch_size
    val_batch_size = args.val_batch_size
    num_epocs = args.num_epocs
    lr_rates = [0.0001, 0.00001, 0.000001]
    model_name = args.model_name
    startf = args.startf 
    endf = args.endf
    starti = args.starti 
    endi = args.endi
    #optim = args.optim
    root = args.root
    split = args.split
    num_workers = args.num_workers
    test_metrics = not args.no_test_metrics


    model_name_save = model_name
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    for optim in args.optim:
        print("STARTING OPTIMIZER: ", optim)

        for fold in range(startf, endf):
            print("FOLD: ", fold)
            dataset_name = dataset.split("/")[-1].split(".")[0]

            for n_m in range(starti, endi): 
                n = str(n_m)
                print("Number: ", n_m)

                writer = tensorboardX.SummaryWriter(log_dir=root+'/runs/'+dataset_name+'_model_'+model_name_save+'_'+str(fold)+'_'+n)
                input_size=224

                if model_name == "vit":
                    model = timm.create_model('vit_base_patch16_224', pretrained=True, num_classes=num_classes)
                elif model_name == "deit":
                    model = timm.create_model('deit_base_distilled_patch16_224', pretrained=True, num_classes=num_classes)
                elif model_name == "swin":
                    model = timm.create_model('swin_base_patch4_window7_224', pretrained=True, num_classes=num_classes)
                elif model_name == "coatnet":
                    model = timm.create_model('coatnet_rmlp_2_rw_224', pretrained=True, num_classes=num_classes)
                elif model_name == "beit":
                    model = timm.create_model('beit_base_patch16_224', pretrained=True, num_classes=num_classes)
                elif model_name == "beit2":
                    model = timm.create_model('beitv2_base_patch16_224', pretrained=True, num_classes=num_classes)
                elif model_name == "beitl":
                    model = timm.create_model('beit_large_patch16_224.in22k_ft_in22k', pretrained=True, num_classes=num_classes)
                elif model_name == "beitl384":
                    model = timm.create_model('beit_large_patch16_384.in22k_ft_in22k_in1k', pretrained=True, num_classes=num_classes)
                    input_size=384
                elif model_name == "beitl2":
                    model = timm.create_model('beitv2_large_patch16_224.in1k_ft_in22k', pretrained=True, num_classes=num_classes)
                elif model_name == "vitl":
                    model = timm.create_model('vit_large_patch16_224', pretrained=True, num_classes=num_classes)
                elif model_name == "vitl384":
                    model = timm.create_model('vit_large_patch32_384.orig_in21k_ft_in1k', pretrained=True, num_classes=num_classes)
                    input_size=384
                elif model_name == "swinl":
                    model = timm.create_model('swin_large_patch4_window7_224.ms_in22k', pretrained=True, num_classes=num_classes)
                elif model_name == "swinl384":
                    model = timm.create_model('swin_large_patch4_window12_384.ms_in22k', pretrained=True, num_classes=num_classes)
                    input_size=384

                if torch.cuda.device_count() > 1:
                    print("Let's use", torch.cuda.device_count(), "GPUs!")
                    model = nn.DataParallel(model)

                model.to(device)

                trainset = PatternData(dataset, mode="train", fold=fold, input_size=input_size, split=split)
                trainloader = torch.utils.data.DataLoader(trainset, batch_size=batch_size, shuffle=True, num_workers=num_workers)
                valset = PatternData(dataset, mode="val", fold=fold, input_size=input_size, split=split)
                valloader = torch.utils.data.DataLoader(valset, batch_size=val_batch_size, shuffle=False, num_workers=num_workers)
                testset = PatternData(dataset, mode="test", fold=fold, input_size=input_size, split=split)
                testloader = torch.utils.data.DataLoader(testset, batch_size=val_batch_size, shuffle=False, num_workers=num_workers)

                criterion = nn.CrossEntropyLoss()

                tot_iter = 0
                best_model = None
                best_f1_loss = 0
                best_f1_acc = 0
                best_f1 = 0
                best_lr = 0
                for l in lr_rates:
                    pat = 0
                    max_pat = 6
                    warmup = 10
                    wd = 0.03

                    #optimizer = torch.optim.AdamW(model.parameters(), lr=l, weight_decay=wd)

                    print("OPTIMIZER: ", optim, " wd: ", args.adamwd)
                    if optim == 'diffgrad':
                        optimizer = DiffGrad(model.parameters(), lr=l, weight_decay=wd, adam_wd=args.adamwd)
                    elif optim == 'dgrad':
                        optimizer = DGrad(model.parameters(), lr=l, weight_decay=wd, adam_wd=args.adamwd)
                    elif optim == 'cos':
                        optimizer = Cos(model.parameters(), lr=l, weight_decay=wd, adam_wd=args.adamwd)
                    elif optim == 'exp':
                        optimizer = Exp(model.parameters(), lr=l, weight_decay=wd, adam_wd=args.adamwd)
                    elif optim == 'hyp':
                        optimizer = Hyp(model.parameters(), lr=l, weight_decay=wd, adam_wd=args.adamwd)
                    elif optim == 'mind':
                        optimizer = MinD(model.parameters(), lr=l, weight_decay=wd, adam_wd=args.adamwd)
                    elif optim == 'ai':
                        optimizer = AngularInjection(model.parameters(), lr=l, weight_decay=wd, adam_wd=args.adamwd)
                    elif optim == 'adam':
                        optimizer = torch.optim.Adam(model.parameters(), lr=l, weight_decay=wd)
                    elif optim == 'adamw':
                        optimizer = torch.optim.AdamW(model.parameters(), lr=l, weight_decay=wd)

                    scheduler = LRScheduler(optimizer)

                    for epoch in range(num_epocs):
                        print(epoch)
                        adjust_learning_rate(optimizer, epoch, l, warmup, False, num_epocs)

                        model.train()
                        avg_loss_train, acc, f1 = train(model, optimizer, trainloader, criterion, num_classes)

                        print("train loss: ", avg_loss_train, " - train accuracy: ", acc, " - f1: ", f1)
                        writer.add_scalar("Loss/Train_loss", avg_loss_train, tot_iter)
                        writer.add_scalar("Accuracy/Train_acc", acc, tot_iter)
                        writer.add_scalar("F1/Train_f1", f1, tot_iter)
                        writer.flush()

                        model.eval()
                        with torch.no_grad():
                            avg_loss, acc, f1 = val(model, valloader, criterion, num_classes)

                            print("val loss: ", avg_loss, " - val accuracy: ", acc, " - f1: ", f1)
                            writer.add_scalar("Loss/Val_loss", avg_loss, tot_iter)
                            writer.add_scalar("Accuracy/Val_acc", acc, tot_iter)
                            writer.add_scalar("F1/Val_f1", f1, tot_iter)
                            writer.flush()

                        if f1 > best_f1:
                            best_f1 = f1
                            best_f1_loss = avg_loss
                            best_f1_acc = acc
                            pat = 0
                            best_model = copy.deepcopy(model).cpu()
                            best_lr = l

                        elif pat > max_pat:
                            break

                        else:
                            pat += 1

                        scheduler(avg_loss_train)

                        tot_iter += 1

                        if acc == 1.0:
                            break
                    if acc == 1.0:
                        break

                out_model_path = root+'/out_models/'+dataset_name+'_model_'+model_name_save+'_'+str(fold)+'_'+n+"_" + str(best_f1) + '_lr_'+ str(best_lr) + "_optim_" + optim + '.pth'

                torch.save({'model_state_dict': best_model.state_dict(),
                            'loss': best_f1_loss,
                            'f1': best_f1,
                            'acc': best_f1_acc,
                            'epoch': 0},
                           out_model_path)

                model.load_state_dict(torch.load(out_model_path)["model_state_dict"])
                model.cuda()
                model.eval()

                out_path_txt = osp.join(root, "out_txt", dataset_name)
                isExist = osp.exists(out_path_txt)
                if not isExist:
                    os.makedirs(out_path_txt)
                    print("created: ", out_path_txt)

                out_path_txt = osp.join(out_path_txt, model_name)
                isExist = osp.exists(out_path_txt)
                if not isExist:
                    os.makedirs(out_path_txt)
                    print("created: ", out_path_txt)

                out_path_txt = osp.join(out_path_txt, optim+str(args.adamwd))
                isExist = osp.exists(out_path_txt)
                if not isExist:
                    os.makedirs(out_path_txt)
                    print("created: ", out_path_txt)

                with torch.no_grad():
                    avg_loss, acc, f1 = test(model, testloader, criterion, file_name=out_path_txt+"/"+model_name + "_" + dataset_name + "_" + optim + "_" + str(fold) + "_" + str(n), nc=num_classes, compute_metrics=test_metrics)
                    print("test loss: ", avg_loss, " - test accuracy: ", acc, " - f1: ", f1)
