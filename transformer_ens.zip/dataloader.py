import mat73
import torch
import torch.nn as nn
from torch.utils.data import Dataset
from torchvision import transforms

from timm.data import create_transform
from timm.data.constants import IMAGENET_DEFAULT_MEAN, IMAGENET_DEFAULT_STD

import scipy.io
from PIL import Image
import numpy as np
import sklearn

def build_transform(is_train, input_size=224):
    resize_im = input_size > 32
    if is_train == "train" or is_train == "tc":
        print("train transforms")
        transform = transforms.Compose([transforms.Resize((input_size, input_size)),
                                        #transforms.ColorJitter(brightness=(0.5, 1.5), contrast=(1), saturation=(0.5, 1.5), hue=(-0.1, 0.1)),
                                        transforms.RandomHorizontalFlip(),
                                        transforms.RandomVerticalFlip(),
                                        #transforms.GaussianBlur(kernel_size=(1, 5), sigma=(0.1, 2)),
                                        transforms.RandomRotation(degrees=(0, 180)),
                                        #transforms.RandomAffine(degrees=(0, 90), translate=0.0, scale=(0.9, 1.1)),
                                        transforms.ToTensor(),
                                        transforms.Normalize(IMAGENET_DEFAULT_MEAN, IMAGENET_DEFAULT_STD)
                                        ])
        return transform

    print("val transforms")
    t = []
    t.append(transforms.Resize((input_size, input_size)))
    t.append(transforms.ToTensor())
    t.append(transforms.Normalize(IMAGENET_DEFAULT_MEAN, IMAGENET_DEFAULT_STD))
    return transforms.Compose(t)


class PatternData(Dataset):
    def __init__(self, path="./data/data.mat", mode="train", transforms=None, fold=0, input_size=224, split=5):

        try:
            print("v7")
            self.raw_data = scipy.io.loadmat(path)["DATA"][0]
            v7 = True
        except:
            self.raw_data = mat73.loadmat(path)['DATA']
            v7 = False
        #self.raw_data = scipy.io.loadmat(path)["DATA"][0]

        self.fold = fold

        if transforms is None:
            self.transform = build_transform(mode, input_size=input_size)
        else:
            self.transform = transforms


        if v7:
            self.NX = self.raw_data[0][0]
            self.NF = len(self.raw_data[2])  # number of folds
            self.DIV = self.raw_data[2]  # division between train and test
            self.DIV = self.DIV - 1  # because Matlab starts from 1

            self.DIM1 = self.raw_data[3][0, 0] # elements for train
            self.DIM2 = self.raw_data[4][0, 0] # elements for test

            y = self.raw_data[1][0]

            self.trainPattern = self.DIV[fold, :self.DIM1]
            self.testPattern = self.DIV[fold, self.DIM1:self.DIM2 + 1]
            self.labelTR = y[self.DIV[fold, :self.DIM1]]
            self.labelTE = y[self.DIV[fold, self.DIM1:self.DIM2 + 1]]
        else:
            self.NX = self.raw_data[0]
            self.NF = 1  # number of folds
            self.DIV = self.raw_data[2]  # division between train and test
            self.DIV = self.DIV - 1  # because Matlab starts from 1

            self.DIM1 = int(self.raw_data[3])  # elements for train
            self.DIM2 = int(self.raw_data[4])  # elements for test

            y = self.raw_data[1].astype(int)

            self.trainPattern = self.DIV[:self.DIM1].astype(int)
            self.testPattern = self.DIV[self.DIM1:self.DIM2 + 1].astype(int)
            self.labelTR = y[self.DIV[:self.DIM1].astype(int)]
            self.labelTE = y[self.DIV[self.DIM1:self.DIM2 + 1].astype(int)]

        self.mode = mode

        #split_train = int(len(self.trainPattern) * 0.8)
        split_train = []
        for i in range(split-1):
            split_train += list(range(i, len(self.trainPattern), split))
        split_train.sort()
        split_val = list(range(split-1, len(self.trainPattern), split))

        #split_train = list(range(0, len(self.trainPattern), 4)) + list(range(1, len(self.trainPattern), 4)) + list(range(2, len(self.trainPattern), 4))
        #split_train.sort()
        #split_val = list(range(3, len(self.trainPattern), 4))

        if self.mode == "train":
            self.pattern = self.trainPattern[split_train]
            self.labels = self.labelTR[split_train]
        elif self.mode == "tc":
            self.pattern = self.trainPattern
            self.labels = self.labelTR
        elif self.mode == "val":
            self.pattern = self.trainPattern[split_val]
            self.labels = self.labelTR[split_val]
        else:
            self.pattern = self.testPattern
            self.labels = self.labelTE

        print("Loaded: ", len(self.pattern), " images")

    def get_weights(self, w_type, cuda=True):
        if w_type == 0:
            self.w = sklearn.utils.class_weight.compute_class_weight(class_weight='balanced', classes=np.unique(self.labelTR), y=self.labelTR)
        elif w_type == 1:
            self.w = len(self.labelTR)/np.bincount(self.labelTR)
        return torch.tensor(self.w).float().cuda()

    def __len__(self):
        return len(self.pattern)

    def __getitem__(self, idx):
        image_id = self.pattern[idx]
        x = self.NX[image_id]
        y = self.labels[idx] - 1 # conversion from matlab

        # stuck more layers to create rgb image
        if len(x.shape) < 3:
            x = np.expand_dims(x, axis=2)
            x = np.concatenate((x.copy(), x.copy(), x.copy()), axis=2)

        x = Image.fromarray(x)
        x = self.transform(x)

        return x, torch.tensor(y)


if __name__ == "__main__":
    dataloader = PatternData(path="../../data/data.mat")