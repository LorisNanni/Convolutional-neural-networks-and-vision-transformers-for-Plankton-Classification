import math

import torch
from torch.optim.optimizer import Optimizer

#from optimizers.optim_types import Betas2, OptFloat, OptLossClosure, Params


class AngularInjection(Optimizer):

    def __init__(self, params, lr=1e-3, betas=(0.9, 0.999), eps=1e-8, weight_decay=0,  a: float = 10.0, b: float = 2/3, c: float = 1.5, adam_wd: bool = False):
        if not 0.0 <= lr:
            raise ValueError("Invalid learning rate: {}".format(lr))
        if not 0.0 <= eps:
            raise ValueError("Invalid epsilon value: {}".format(eps))
        if not 0.0 <= betas[0] < 1.0:
            raise ValueError("Invalid beta parameter at index 0: {}".format(betas[0]))
        if not 0.0 <= betas[1] < 1.0:
            raise ValueError("Invalid beta parameter at index 1: {}".format(betas[1]))

        self.a = a
        self.b = b
        self.c = c

        defaults = dict(lr=lr, betas=betas, eps=eps, weight_decay=weight_decay, a=a, b=b, c=c, adam_wd=adam_wd)
        super(AngularInjection, self).__init__(params, defaults)

    def __setstate__(self, state):
        super(AngularInjection, self).__setstate__(state)

    def step(self, closure=None):
        """Performs a single optimization step.
        Arguments:
            closure (callable, optional): A closure that reevaluates the model
                and returns the loss.
        """
        loss = None
        if closure is not None:
            loss = closure()

        for group in self.param_groups:
            for p in group['params']:
                if p.grad is None:
                    continue
                grad = p.grad.data
                if grad.is_sparse:
                    raise RuntimeError(
                        'cosangulargrad does not support sparse gradients, please consider SparseAdam instead')

                state = self.state[p]

                # State initialization
                if len(state) == 0:
                    state['step'] = 0
                    # Exponential moving average of gradient values
                    state['exp_avg'] = torch.zeros_like(p.data)
                    # Exponential moving average of squared gradient values
                    state['exp_avg_sq'] = torch.zeros_like(p.data)
                    # Previous gradient
                    state['previous_grad'] = torch.zeros_like(p.data)
                    # prev angle
                    state['previous_angle'] = torch.zeros_like(p.data)
                    # avg
                    state['avg'] = torch.zeros_like(p.data)
                    # avgsq
                    state['avgsq'] = torch.zeros_like(p.data)
                    # p t-2
                    state['p_t2'] = torch.zeros_like(p.data)

                exp_avg, exp_avg_sq = state['exp_avg'].clone(), state['exp_avg_sq'].clone()
                previous_grad = state['previous_grad'].clone()
                prev_angle = state['previous_angle'].clone()

                beta1, beta2 = group['betas']

                state['step'] += 1

                if group['adam_wd']:
                    p.data.mul_(1 - group['lr'] * group['weight_decay'])
                else:
                    if group['weight_decay'] != 0:
                        grad.add_(p.data, alpha=group['weight_decay'])

                if state['step'] <= 1:

                    # Decay the first and second moment running average coefficient
                    exp_avg.mul_(beta1).add_(1 - beta1, grad)
                    exp_avg_sq.mul_(beta2).addcmul_(1 - beta2, grad, grad)
                    denom = exp_avg_sq.sqrt().add_(group['eps'])

                    xit = 1.0

                    # p.data.addcdiv_(exp_avg, denom, value=group['lr'])

                else:
                    gs = torch.square(grad.clone()) # eq 28
                    k = 2 # eq 29

                    delta = torch.sub(state['p_t2'], p.data)  # eq 31
                    exp_avg = torch.add(beta1 * exp_avg, (1 - beta1) * (torch.sub(grad, torch.mul(delta, gs))) / k)  # eq 30
                    exp_avg_sq = torch.add(beta2 * exp_avg_sq, torch.mul((1 - beta2), gs)) # eq 32
                    denom = exp_avg_sq.sqrt().add_(group['eps']) # den ed 33

                    tan_theta = abs((previous_grad - grad) / (1 + previous_grad * grad)) # eq 24
                    angle = torch.atan(tan_theta) * (180 / 3.141592653589793238) # eq 24

                    if state['step'] <= 2:
                        xit = 1.0

                    else:
                        angle_min = torch.minimum(angle, prev_angle) # eq 25
                        lrt = torch.div(-1, self.a * angle_min + self.b) + self.c # eq 26
                        xit = torch.div(lrt, torch.max(lrt) + group['eps']) # eq 27

                    state['previous_angle'] = angle.clone()

                # update prev states
                state['previous_grad'] = grad.clone()
                state['exp_avg'] = exp_avg.clone()
                state['exp_avg_sq'] = exp_avg_sq.clone()
                state['p_t2'] = p.data.clone()

                # update momentum with dfc
                exp_avg1 = exp_avg * xit

                # compute step size
                bias_correction1 = 1 - beta1 ** state['step']  # denom eq 4
                bias_correction2 = 1 - beta2 ** state['step']  # denom eq 5
                step_size = (
                        group['lr']  # alpha
                        * math.sqrt(bias_correction2)  # for eq 5
                        / bias_correction1  # for eq 4
                )

                p.data.addcdiv_(exp_avg1, denom, value=-step_size)  # eq 10

        return loss

