import math

import torch
from torch.optim.optimizer import Optimizer

from optim_types import Betas2, OptFloat, OptLossClosure, Params

__all__ = ('DiffGrad',)

