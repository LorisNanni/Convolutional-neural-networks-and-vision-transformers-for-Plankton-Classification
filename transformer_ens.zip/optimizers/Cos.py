import math

import torch
from torch.optim.optimizer import Optimizer

from optimizers.optim_types import Betas2, OptFloat, OptLossClosure, Params


class Cos(Optimizer):
    r"""Implements DiffGrad algorithm.

    It has been proposed in `DiffGrad: An Optimization Method for
    Convolutional Neural Networks`__.

    Arguments:
        params: iterable of parameters to optimize or dicts defining
            parameter groups
        lr: learning rate (default: 1e-3)
        betas: coefficients used for computing
            running averages of gradient and its square (default: (0.9, 0.999))
        eps: term added to the denominator to improve
            numerical stability (default: 1e-8)
        weight_decay: weight decay (L2 penalty) (default: 0)

    __ https://arxiv.org/abs/1909.11015

    Note:
        Reference code: https://github.com/shivram1987/diffGrad
    """

    def __init__(self, params: Params, lr: float = 1e-3, betas: Betas2 = (0.9, 0.999), eps: float = 1e-8,
                 weight_decay: float = 0.0, steps: int = 30, adam_wd: bool = False) -> None:
        if lr <= 0.0:
            raise ValueError('Invalid learning rate: {}'.format(lr))
        if eps < 0.0:
            raise ValueError('Invalid epsilon value: {}'.format(eps))
        if not 0.0 <= betas[0] < 1.0:
            raise ValueError(
                'Invalid beta parameter at index 0: {}'.format(betas[0])
            )
        if not 0.0 <= betas[1] < 1.0:
            raise ValueError(
                'Invalid beta parameter at index 1: {}'.format(betas[1])
            )
        if weight_decay < 0.0:
            raise ValueError(
                'Invalid weight_decay value: {}'.format(weight_decay)
            )

        self.steps = steps

        defaults = dict(lr=lr, betas=betas, eps=eps, weight_decay=weight_decay, steps=steps, adam_wd=adam_wd)
        super(Cos, self).__init__(params, defaults)

    def step(self, closure: OptLossClosure = None) -> OptFloat:
        r"""Performs a single optimization step.

        Arguments:
            closure: A closure that reevaluates the model and returns the loss.
        """
        loss = None
        if closure is not None:
            loss = closure()

        for group in self.param_groups:
            beta1, beta2 = group['betas']

            for p in group['params']:
                if p.grad is None:
                    continue
                grad = p.grad.data
                if grad.is_sparse:
                    msg = (
                        'DiffGrad does not support sparse gradients, '
                        'please consider SparseAdam instead'
                    )
                    raise RuntimeError(msg)

                state = self.state[p]

                # State initialization
                if len(state) == 0:
                    state['step'] = 0
                    # Exponential moving average of gradient values
                    state['exp_avg'] = torch.zeros_like(p)
                    # Exponential moving average of squared gradient values
                    state['exp_avg_sq'] = torch.zeros_like(p)
                    # Previous gradient
                    state['previous_grad'] = torch.zeros_like(p)
                    # Window
                    #s = torch.tensor(p.unsqueeze(0).size())
                    #s[0] *= self.w
                    #state['windows_grad'] = torch.zeros(torch.Size(s.numpy()), dtype=p.dtype, layout=p.layout,
                    #                                    device=p.device)

                '''
                exp_avg, exp_avg_sq, previous_grad, windows_grad = (
                    state['exp_avg'], # m_(t-1)
                    state['exp_avg_sq'], # v_(t-1)
                    state['previous_grad'], # g_(t-1)
                    state['windows_grad'],
                )
                '''

                exp_avg, exp_avg_sq, previous_grad = (
                    state['exp_avg'],  # m_(t-1)
                    state['exp_avg_sq'],  # v_(t-1)
                    state['previous_grad'],  # g_(t-1)

                )

                state['step'] += 1

                # update window
                # window_pos = state['step'] % self.w
                # state['windows_grad'][window_pos] = torch.mul(grad, grad)

                if group['adam_wd']:
                    p.data.mul_(1 - group['lr'] * group['weight_decay'])
                else:
                    if group['weight_decay'] != 0:
                        grad.add_(p.data, alpha=group['weight_decay'])

                # Decay the first and second moment running average coefficient
                exp_avg.mul_(beta1).add_(grad, alpha=1 - beta1)
                exp_avg_sq.mul_(beta2).addcmul_(grad, grad, value=1 - beta2)
                avg = exp_avg_sq.clone()
                denom = exp_avg_sq.sqrt().add_(group['eps'])

                bias_correction1 = 1 - beta1 ** state['step']
                bias_correction2 = 1 - beta2 ** state['step']

                # new lr_t
                l_cos = torch.abs(torch.cos(torch.div(math.pi * state['step'], self.steps))) # eq 15
                l_exp = torch.exp(torch.mul(-0.01, (state['step'] % self.steps) + 1)) # eq 15
                lr_t = 2 - torch.mul(l_cos, l_exp) # eq 15

                # average of window
                #avg = torch.sum(windows_grad, dim=0) / self.w

                # new difference
                ag_t = torch.abs(grad - avg)
                ag_t_ = ag_t / torch.max(ag_t)
                dfc = torch.div(1.0, (1.0 + torch.exp(-ag_t_ * 4 * lr_t))) # eq 16

                # update previous grad
                state['previous_grad'] = grad.clone()

                # update momentum with dfc
                exp_avg1 = exp_avg * dfc

                step_size = (
                        group['lr']
                        * math.sqrt(bias_correction2)
                        / bias_correction1
                )

                p.data.addcdiv_(exp_avg1, denom, value=-step_size)

        return loss

